These files are required for this mod to work on Windows.

They need to be installed in the main KSP directory,

       NOT THE GameData directory!!!!
